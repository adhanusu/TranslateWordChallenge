
import csv
import re
import time
import psutil

start = time.time()
wordsintxt = open("find_words.txt", "r")
findwords = wordsintxt.read()
wordsintxt.close()
wordstofind = findwords.split()
frq = {}
shakespeare_text = open("t8.shakespeare.txt", 'r')
text = shakespeare_text.read().lower()
matchpattern = re.findall(r'\b[a-z]{3,15}\b', text)
with open('french_dictionary.csv', mode='r') as data:
    read = csv.reader(data)
    dictionary = {rows[0]: rows[1] for rows in read}
total_eng = []
for word in matchpattern:
    if word in wordstofind:
        total_eng.append(word)
engish = set(total_eng)
engish = list(engish)
french = []
for x in engish:
    for key, value in dictionary.items():
        if x in key:
            french.append(value)
frq = {}
for y in total_eng:
    count = frq.get(y, 0)
    frq[y] = count + 1

freqlist = frq.keys()
fy = []
for z in freqlist:
    fy.append(frq[z])
total = list(zip(engish, french, fy))
header = ['English Word', 'French Word', 'Frequency']
with open('frequency.csv', 'w', encoding='UTF8') as fy:
    wrt = csv.writer(fy)
    wrt.writerow(header)

    for row in total:
        for x in row:
            fy.write(str(x) + ',')
        fy.write('\n')
test_str = text
lookp_dict = dictionary

temp = test_str.split()
result = []
for wrd in temp:
    result.append(lookp_dict.get(wrd, wrd))

result = ' '.join(result)

fy = open("t8.shakespeare.translated.txt", "w")
fy.write(str(result))
fy.close()
time_taken = time.time() - start
memory_taken = psutil.cpu_percent(time_taken)
fy = open("performance.txt", "w")
fy.write(f'Time to process: 0 minutes {time_taken} seconds\nMemory used: {memory_taken} MB')
fy.close()
print("Translated successfully")
